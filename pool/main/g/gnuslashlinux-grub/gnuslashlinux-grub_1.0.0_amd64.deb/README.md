# GNUSlashLinux_grub_theme

Grub Theme for GNUSlashLinux
