# GNUSlashLinux_grub_minimal_theme

Grub-Minimal Theme for GNUSlashLinux
