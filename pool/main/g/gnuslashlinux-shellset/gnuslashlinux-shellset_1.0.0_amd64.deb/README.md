# GNUSlashLinux_shellset

Shellset for GNUSlashLinux
