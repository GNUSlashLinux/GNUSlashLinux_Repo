# GNUSlashLinux_wallpapers_nord

Wallpapers Nord for GNUSlashLinux