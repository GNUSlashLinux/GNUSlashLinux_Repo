# GNUSlashLinux_plymouth_minimal_theme

Plymouth-Minimal Theme for GNUSlashLinux
