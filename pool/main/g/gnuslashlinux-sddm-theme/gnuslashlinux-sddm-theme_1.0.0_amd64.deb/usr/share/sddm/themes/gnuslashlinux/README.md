# GNUSlashLinux(SDDM Theme)

Simple dark SDDM theme with many customization options.

## Install from KDE system settings

If you're using KDE, you can install theme from `System Settings > Startup and Shutdown > Login Screen (SDDM)`. You can download this repo as zip and install with `Install From File...`, or you can find it in `Get New Login Screens...` window.

## Configuration

Create file `theme.conf.user` in theme folder. See `theme.conf` for reference.

### Base options

* `background` - path to background image. If not set, falls back to `color_bg`. Not set by default.
* `bg_mode` - background image fill mode. Can be either `aspect`, `fill`, `tile` or `none`. Defaults to `aspect`.
* `parallax_bg_shift` - shifting of parallax background on tab change in pixels. `0` disables parallax motion. Negative values will scroll background in opposite direction. Default is `20`.
* `manual` - enables manual login mode and disables user selection. You can use "0/1", "true/false" and "yes/no" on this option. Disabled by default.

### Color scheme

There are many color options.

* `color_bg` - background color. Defaults to `#222222`.
* `color_main` - main color. Defaults to `#dddddd`.
* `color_dimmed` - dimmed main color. Defaults to `#888888`.
* `color_contrast` - color that contrasting to both main and dimmed. Defaults to `#1f1f1f`.


### Font scheme

There are also many font options.

* `font` - overall font. Defaults to `Roboto`.

### Debug mode options

There are some things that can't be tested well in greeter (e.g. shutdown options or login error). So there is a debug mode.

#### Boolean options

> You can use "0/1", "true/false" and "yes/no" on boolean options. All debug options are disabled by default.

* `debug` - activates debug mode.
* `debug_can_power_off` - sets `sddm.canPowerOff` (shows "Shutdown").
* `debug_can_reboot` - sets `sddm.canReboot` (shows "Reboot").
* `debug_can_suspend` - sets `sddm.canSuspend` (shows "Suspend").
* `debug_can_hibernate` - sets `sddm.canHibernate` (shows "Hibernate").
* `debug_can_hybrid_sleep` - sets `sddm.canHybridSleep` (shows "Hybrid Sleep").
* `debug_login_error` - forces login error.

#### Number options

* `debug_login_timeout` - time between pressing "Login" and login error in seconds. Not effective if `debug_login_error` is disabled.

#### String options

* `debug_hostname` - sets `sddm.hostName`.
