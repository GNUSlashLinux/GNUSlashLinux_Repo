# GNUSlashLinux_plymouth_theme

Plymouth Theme for GNUSlashLinux
